import django.db.models.deletion
import uuid
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("library", "0001_initial"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="Emprunt",
            fields=[
                (
                    "id",
                    models.UUIDField(
                        default=uuid.uuid4,
                        editable=False,
                        primary_key=True,
                        serialize=False,
                    ),
                ),
                ("date_emprunt", models.DateTimeField(auto_now_add=True)),
                ("date_retour", models.DateTimeField()),
                ("est_retourne", models.BooleanField(default=False)),
            ],
            options={
                "verbose_name": "Emprunt",
                "verbose_name_plural": "Emprunts",
                "ordering": ["-date_emprunt"],
            },
        ),
        migrations.AlterModelOptions(
            name="library",
            options={},
        ),
        migrations.RemoveIndex(
            model_name="library",
            name="library_lib_type_b53700_idx",
        ),
        migrations.RemoveIndex(
            model_name="library",
            name="library_lib_titre_2e129e_idx",
        ),
        migrations.RemoveIndex(
            model_name="library",
            name="library_lib_auteur_636f80_idx",
        ),
        migrations.RemoveIndex(
            model_name="library",
            name="library_lib_langue_1c4b1e_idx",
        ),
        migrations.AlterField(
            model_name="library",
            name="auteur",
            field=models.CharField(max_length=255),
        ),
        migrations.AlterField(
            model_name="library",
            name="categorie",
            field=models.CharField(blank=True, max_length=255, null=True),
        ),
        migrations.AlterField(
            model_name="library",
            name="created_at",
            field=models.DateTimeField(auto_now_add=True),
        ),
        migrations.AlterField(
            model_name="library",
            name="date_publication",
            field=models.DateField(blank=True, null=True),
        ),
        migrations.AlterField(
            model_name="library",
            name="description",
            field=models.TextField(),
        ),
        migrations.AlterField(
            model_name="library",
            name="editeur",
            field=models.CharField(blank=True, max_length=255, null=True),
        ),
        migrations.AlterField(
            model_name="library",
            name="est_public",
            field=models.BooleanField(default=True),
        ),
        migrations.AlterField(
            model_name="library",
            name="format",
            field=models.CharField(
                choices=[("pdf", "PDF"), ("epub", "EPUB"), ("mobi", "MOBI")],
                max_length=5,
            ),
        ),
        migrations.AlterField(
            model_name="library",
            name="isbn",
            field=models.CharField(blank=True, max_length=13, null=True),
        ),
        migrations.AlterField(
            model_name="library",
            name="langue",
            field=models.CharField(
                choices=[("fr", "Français"), ("en", "Anglais")], max_length=2
            ),
        ),
        migrations.AlterField(
            model_name="library",
            name="mots_cles",
            field=models.TextField(blank=True, null=True),
        ),
        migrations.AlterField(
            model_name="library",
            name="nombre_pages",
            field=models.IntegerField(blank=True, null=True),
        ),
        migrations.AlterField(
            model_name="library",
            name="nombre_telechargements",
            field=models.IntegerField(default=0),
        ),
        migrations.AlterField(
            model_name="library",
            name="taille_fichier",
            field=models.IntegerField(blank=True, null=True),
        ),
        migrations.AlterField(
            model_name="library",
            name="titre",
            field=models.CharField(max_length=255),
        ),
        migrations.AlterField(
            model_name="library",
            name="type",
            field=models.CharField(
                choices=[("book", "Livre"), ("document", "Document")], max_length=10
            ),
        ),
        migrations.AlterField(
            model_name="library",
            name="type_document",
            field=models.CharField(blank=True, max_length=255, null=True),
        ),
        migrations.AlterField(
            model_name="library",
            name="updated_at",
            field=models.DateTimeField(auto_now=True),
        ),
        migrations.AlterField(
            model_name="library",
            name="url",
            field=models.URLField(),
        ),
        migrations.AddField(
            model_name="emprunt",
            name="resource",
            field=models.ForeignKey(
                on_delete=django.db.models.deletion.CASCADE, to="library.library"
            ),
        ),
        migrations.AddField(
            model_name="emprunt",
            name="user",
            field=models.ForeignKey(
                on_delete=django.db.models.deletion.CASCADE, to=settings.AUTH_USER_MODEL
            ),
        ),
    ]
