import uuid
from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name="Library",
            fields=[
                (
                    "id",
                    models.UUIDField(
                        default=uuid.uuid4,
                        editable=False,
                        primary_key=True,
                        serialize=False,
                    ),
                ),
                (
                    "type",
                    models.CharField(
                        choices=[("book", "Livre"), ("document", "Document")],
                        max_length=20,
                        verbose_name="Type",
                    ),
                ),
                ("titre", models.CharField(max_length=255, verbose_name="Titre")),
                ("auteur", models.CharField(max_length=255, verbose_name="Auteur")),
                ("description", models.TextField(verbose_name="Description")),
                (
                    "langue",
                    models.CharField(
                        choices=[
                            ("fr", "Français"),
                            ("en", "Anglais"),
                            ("es", "Espagnol"),
                            ("de", "Allemand"),
                        ],
                        default="fr",
                        max_length=2,
                        verbose_name="Langue",
                    ),
                ),
                (
                    "format",
                    models.CharField(
                        choices=[
                            ("pdf", "PDF"),
                            ("epub", "EPUB"),
                            ("mobi", "MOBI"),
                            ("doc", "DOC"),
                            ("docx", "DOCX"),
                            ("txt", "TXT"),
                        ],
                        max_length=10,
                        verbose_name="Format",
                    ),
                ),
                (
                    "url",
                    models.URLField(
                        help_text="URL de la couverture pour les livres, URL de téléchargement pour les documents",
                        verbose_name="URL",
                    ),
                ),
                (
                    "est_public",
                    models.BooleanField(default=True, verbose_name="Est public"),
                ),
                (
                    "created_at",
                    models.DateTimeField(auto_now_add=True, verbose_name="Créé le"),
                ),
                (
                    "updated_at",
                    models.DateTimeField(auto_now=True, verbose_name="Modifié le"),
                ),
                (
                    "isbn",
                    models.CharField(
                        blank=True, max_length=13, null=True, verbose_name="ISBN"
                    ),
                ),
                (
                    "date_publication",
                    models.DateField(
                        blank=True, null=True, verbose_name="Date de publication"
                    ),
                ),
                (
                    "editeur",
                    models.CharField(
                        blank=True, max_length=255, null=True, verbose_name="Éditeur"
                    ),
                ),
                (
                    "nombre_pages",
                    models.IntegerField(
                        blank=True, null=True, verbose_name="Nombre de pages"
                    ),
                ),
                (
                    "categorie",
                    models.CharField(
                        blank=True, max_length=100, null=True, verbose_name="Catégorie"
                    ),
                ),
                (
                    "type_document",
                    models.CharField(
                        blank=True,
                        max_length=50,
                        null=True,
                        verbose_name="Type de document",
                    ),
                ),
                (
                    "taille_fichier",
                    models.IntegerField(
                        blank=True, null=True, verbose_name="Taille du fichier (en Ko)"
                    ),
                ),
                (
                    "mots_cles",
                    models.TextField(blank=True, null=True, verbose_name="Mots-clés"),
                ),
                (
                    "nombre_telechargements",
                    models.IntegerField(
                        default=0, verbose_name="Nombre de téléchargements"
                    ),
                ),
            ],
            options={
                "verbose_name": "Ressource",
                "verbose_name_plural": "Ressources",
                "ordering": ["-created_at"],
                "indexes": [
                    models.Index(fields=["type"], name="library_lib_type_b53700_idx"),
                    models.Index(fields=["titre"], name="library_lib_titre_2e129e_idx"),
                    models.Index(
                        fields=["auteur"], name="library_lib_auteur_636f80_idx"
                    ),
                    models.Index(
                        fields=["langue"], name="library_lib_langue_1c4b1e_idx"
                    ),
                ],
            },
        ),
    ]
