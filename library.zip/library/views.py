from django.http import FileResponse, Http404, HttpResponse
from django.utils.text import slugify
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from datetime import datetime, timedelta
import os
from .models import Library, Emprunt, Subscription
from .serializers import LibrarySerializer, EmpruntSerializer, SubscriptionSerializer

class LibraryListCreateView(generics.ListCreateAPIView):
    serializer_class = LibrarySerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def get_queryset(self):
        queryset = Library.objects.all()
        type = self.request.query_params.get('type', None)
        if type is not None:
            queryset = queryset.filter(type=type)
        return queryset

class LibraryDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Library.objects.all()
    serializer_class = LibrarySerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

class EmpruntView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk):
        try:
            active_subscription = Subscription.objects.filter(
                user=request.user,
                status='active',
                end_date__gt=datetime.now()
            ).exists()

            if not active_subscription:
                return Response(
                    {"detail": "Un abonnement actif est requis pour emprunter"},
                    status=status.HTTP_403_FORBIDDEN
                )

            resource = Library.objects.get(pk=pk)
            
            if Emprunt.objects.filter(
                user=request.user,
                resource=resource,
                est_retourne=False
            ).exists():
                return Response(
                    {"detail": "Vous avez déjà emprunté cette ressource"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            emprunts_actifs = Emprunt.objects.filter(
                user=request.user,
                est_retourne=False
            ).count()
            
            if emprunts_actifs >= 5:
                return Response(
                    {"detail": "Vous avez atteint le nombre maximum d'emprunts simultanés (5)"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            duration = request.data.get('duration', 7) 
            if duration not in [7, 14, 30]:
                duration = 7
            
            date_retour = datetime.now() + timedelta(days=duration)
            emprunt = Emprunt.objects.create(
                user=request.user,
                resource=resource,
                date_retour=date_retour
            )
            
            return Response(
                EmpruntSerializer(emprunt).data,
                status=status.HTTP_201_CREATED
            )
            
        except Library.DoesNotExist:
            raise Http404

class PDFView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, pk):
        try:
            active_subscription = Subscription.objects.filter(
                user=request.user,
                status='active',
                end_date__gt=datetime.now()
            ).exists()

            if not active_subscription:
                return Response(
                    {"detail": "Un abonnement actif est requis pour accéder aux documents"},
                    status=status.HTTP_403_FORBIDDEN
                )

            resource = Library.objects.get(pk=pk)
            
            emprunt = Emprunt.objects.filter(
                user=request.user,
                resource=resource,
                est_retourne=False
            ).first()
            
            if not emprunt:
                return Response(
                    {"detail": "Vous devez d'abord emprunter cette ressource"},
                    status=status.HTTP_403_FORBIDDEN
                )
            
            pdf_path = resource.get_pdf_path()
            if not os.path.exists(pdf_path):
                from library.utils import create_sample_pdf
                content = f"""
                Titre: {resource.titre}
                Auteur: {resource.auteur}
                Description: {resource.description}
                
                Ceci est un exemple de contenu PDF pour {resource.titre}.
                """
                create_sample_pdf(
                    resource.titre,
                    resource.auteur,
                    content,
                    pdf_path
                )
            
            with open(pdf_path, 'rb') as pdf:
                response = HttpResponse(pdf.read(), content_type='application/pdf')
                response['Content-Disposition'] = f'inline; filename="{slugify(resource.titre)}.pdf"'
                response['X-Frame-Options'] = 'SAMEORIGIN'
                response['Access-Control-Allow-Origin'] = '*'
                response['Access-Control-Allow-Methods'] = 'GET, OPTIONS'
                response['Access-Control-Allow-Headers'] = 'Authorization, Content-Type'
                return response
            
        except Library.DoesNotExist:
            raise Http404
        except Exception as e:
            return Response(
                {"detail": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class BorrowedBooksView(generics.ListAPIView):
    serializer_class = EmpruntSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Emprunt.objects.filter(
            user=self.request.user,
            est_retourne=False
        ).select_related('resource').order_by('-date_emprunt')

class BorrowHistoryView(generics.ListAPIView):
    serializer_class = EmpruntSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Emprunt.objects.filter(
            user=self.request.user,
            est_retourne=True
        ).select_related('resource').order_by('-date_emprunt')

class ReturnBookView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk):
        try:
            emprunt = Emprunt.objects.get(
                pk=pk,
                user=request.user,
                est_retourne=False
            )
            emprunt.est_retourne = True
            emprunt.save()
            
            return Response(
                {"detail": "Livre retourné avec succès"},
                status=status.HTTP_200_OK
            )
        except Emprunt.DoesNotExist:
            raise Http404

class SubscriptionCreateView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        try:
            active_subscription = Subscription.objects.filter(
                user=request.user,
                status='active',
                end_date__gt=datetime.now()
            ).first()

            if active_subscription:
                return Response(
                    {"detail": "Vous avez déjà un abonnement actif"},
                    status=status.HTTP_400_BAD_REQUEST
                )

            subscription = Subscription.objects.create(
                user=request.user,
                type=request.data.get('type'),
                price=request.data.get('price')
            )

            return Response(
                SubscriptionSerializer(subscription).data,
                status=status.HTTP_201_CREATED
            )

        except Exception as e:
            return Response(
                {"detail": str(e)},
                status=status.HTTP_400_BAD_REQUEST
            )

class SubscriptionStatusView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        subscription = Subscription.objects.filter(
            user=request.user,
            status='active',
            end_date__gt=datetime.now()
        ).first()

        return Response({
            "is_active": bool(subscription),
            "subscription": SubscriptionSerializer(subscription).data if subscription else None
        })